# bluefb

$ pkg update && upgrade
$ pkg install python2
$ pkg install git
$ pip2 install mechanize
$ pip2 install requests
$ git clone http://github.com/mr-jucky/bluefb
